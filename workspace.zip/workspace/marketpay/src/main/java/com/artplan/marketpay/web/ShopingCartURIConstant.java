package com.artplan.marketpay.web;

public class ShopingCartURIConstant {
    public static final String SHOPING_CART_URI = "/shopingcart";
    public static final String TEST_URI = "/test";
    
    public static final String GET_URI = "/get/{testId}";
    public static final String ID_VAR = "testId";
    
    public static final String TEST2_URI="test2";
    
    public static final String TEST3_URI="test3";
    public static final String ACTION_PARAM="test3";
    
    public static final String CREATE_ORDER_URI="createorder";
    
    public static final String ORDER_CHANGE_STATE_URI="changeorderstate/{orderId}";
    public static final String ORDER_ID_VAR = "orderId";
    public static final String ORDER_STATE_PARAM = "state";
    
    public static final String ORDERS_BY_USER="getordersbyuser/{userId}";
    public static final String USER_ID_VAR = "userId";
    
    public static final String ORDER_DETAILS_URI = "getorderdetails/{orderId}";
    
}
