package com.artplan.marketpay.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import static com.artplan.marketpay.web.ShopingCartURIConstant.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.artplan.marketpay.model.Order;
import com.artplan.marketpay.model.OrderStates;

/**
 * MARKETPAY-4
 * Request URL: http://localhost:8080/marketpay/shopingcart/test
 * Request URL: http://localhost:8080/marketpay/shopingcart/get/123
 * Request URL: http://localhost:8080/marketpay/shopingcart/test2
 * Request URL: http://localhost:8080/marketpay/shopingcart/test3?action=test
 * 
 * MARKETPAY-5
 * Request URL: http://localhost:8080/marketpay/shopingcart/createorder
 * 
 * MARKETPAY-6
 * Request URL: http://localhost:8080/marketpay/shopingcart/changeorderstate/123?state=ACCEPTED
 * 
 * MARKETPAY-7
 * Request URL: http://localhost:8080/marketpay/shopingcart/getordersbyuser/1
 * 
 * MARKETPAY-8
 * Request URL: http://localhost:8080/marketpay/shopingcart/getorderdetails/1
 * 
 * @author ilya
 *
 */
@RestController
@RequestMapping(SHOPING_CART_URI)
public class ShopingCart {
	
	@RequestMapping(value=TEST_URI, method = RequestMethod.GET, produces = "application/json")	
	@ResponseBody
	public String test(Model model){
		model.addAttribute("msg","Test Shoping Cart method");
		return "{\"msg\":\"Test Shoping Cart method\"}";
	}
	
	@RequestMapping(value=GET_URI, method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public String get(Model model, @PathVariable(ID_VAR) Long testId){
		model.addAttribute("id",testId);
		model.addAttribute("product","Test photo");
		return "{\"id\":\""+testId+"\",\"product\":\"Test Shoping Cart method\"}";
	}
	
	@RequestMapping(value=TEST2_URI, method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public String test2(HttpServletRequest request, HttpSession session){
		return "{\"msg\":\"test2\"}";
	}
	
	@RequestMapping(value=TEST3_URI, method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public String test3(@RequestParam("action") String action){
		return "{\"action\":\""+action+"\"}";
	}
	
	@RequestMapping(value=CREATE_ORDER_URI, method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public String createorder(HttpServletRequest request, HttpSession session){
		Order order = new Order();
		order.setId(123);
		order.setUserId(1);
		return order.toString();
	}
	
	@RequestMapping(value=ORDER_CHANGE_STATE_URI, method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public String changestateorder(@PathVariable(ORDER_ID_VAR) Long orderId, @RequestParam(ORDER_STATE_PARAM) String state){
		
		Order order = new Order();
		order.setId(orderId);
		order.setUserId(1);
		String st = state.toUpperCase();
		if(st.equals("ACCEPTED")){
			order.setState(OrderStates.ACCEPTED);
		} else {
			order.setState(OrderStates.DONE);
		}
		return order.toString();
	}
	
	/*
	 *     public static final String ORDERS_BY_USER="getordersbyuser";
    public static final String USER_ID_VAR = "orderId";
	 */
	
	@RequestMapping(value=ORDERS_BY_USER, method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public String getOrdersByUser(@PathVariable(USER_ID_VAR) Long userId){
		Order order1 = new Order();
		order1.setId(1);
		order1.setUserId(userId);
		Order order2 = new Order();
		order2.setId(2);
		order2.setUserId(userId);
		Order order3 = new Order();
		order3.setId(3);		
		order3.setUserId(userId);
		return "["+order1+","+order2+","+order3+"]";
	}
	
	
	@RequestMapping(value=ORDER_DETAILS_URI, method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public String changestateorder(@PathVariable(ORDER_ID_VAR) Long orderId){
		
		Order order = new Order();
		order.setId(orderId);
		order.setUserId(1);
		return order.toString();
	}	
	
}
