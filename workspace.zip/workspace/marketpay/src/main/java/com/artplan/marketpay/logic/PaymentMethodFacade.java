package com.artplan.marketpay.logic;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Request URL: http://localhost:8080/marketpay/payment/pay
 * 
 * @author ilya
 *
 */
@Controller
@RequestMapping("/payment")
public class PaymentMethodFacade {

	@RequestMapping(value="/pay", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public String doPay(Object payment){
		return "SUCCESSFUL";
	}
}
