package com.artplan.marketpay.model;

public class User {
	private long id;
	private String name;
	
	public void setId(long id){
		this.id = id;
	}
	
	public long getId(){
		return id;
	}
	
	public String getName(){
		return name;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public String toString(){
		return "{\"id\":\""+id+"\",\"name\":\""+name+"\"}";
	}
	
}
