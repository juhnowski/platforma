package com.artplan.marketpay.model;

public class Order {
	private long id;
	private OrderStates state = OrderStates.NEW;
	private long userId;
	
	public void setId(long id){
		this.id = id;
	}
	
	public long getId(){
		return id;
	}
	
	public void setState(OrderStates state){
		this.state = state;
	}
	
	public OrderStates getState(){
		return state;
	}

	public void setUserId(long userId){
		this.userId = userId;
	}
	
	public long getUserId(){
		return id;
	}	
	
	public String toString(){
		return "{\"id\":\""+id+"\",\"state\":\""+state+"\",\"userId\":\""+userId+"\"}";
	}
}
